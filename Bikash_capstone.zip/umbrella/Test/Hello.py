from apiTransformer.apiTransformer import ApiToOpenAPIClient
from apiTransformer.models.url_transformation_input import UrlTransformationInput
from apiTransformer.models.export_formats import ExportFormats
from apiTransformer.exceptions.api_exception import APIException
from prance import ResolvingParser
from datamodel_code_generator import InputFileType, chdir, generate
from datamodel_code_generator.__main__ import Exit, main
from pathlib import Path
from openapi3 import OpenAPI
import yaml
from swagger_parser import SwaggerParser
import countries_model, weather_model
import os
import json
from fastapi_code_generator.__main__ import main, generate_code
from pathlib import Path
from os import listdir
from os.path import isfile, join

# client = ApiToOpenAPIClient()
# transformation_controller = client.transformation
# ur_laddress = UrlTransformationInput()
# ur_laddress.file_url = 'https://app.swaggerhub.com/apis/K2ANZ/GetCountries/1.0.0#/Rest/GetByCountryName'
# ur_laddress.export_format = ExportFormats.OPENAPI3YAML
# ur_laddress.code_gen_version = 1
#
# try:
#     result = transformation_controller.transform_via_url(ur_laddress)
#     print(result.id)
# except APIException as e:
#     print(e)
#
# transformation_controller = client.transformation
# transformation_id = result.id
#
# try:
#     resultGet = transformation_controller.download_transformed_file(transformation_id)
#     print(json.loads(json.dumps(resultGet.decode('utf-8').replace('\r', '').replace('\n', ' '))))
#     with open('../data.json', 'w', encoding='utf-8') as f:
#         json.dump(json.loads(json.dumps(resultGet.decode('utf-8').replace('\r', ''))), f, ensure_ascii=False, indent=4)
# except APIException as e:
#     print(e)
#
# try:
#     resultGet = transformation_controller.get_a_transformation(transformation_id)
#     print(json.loads(json.dumps(resultGet.decode('utf-8').replace('\r', '').replace('\n', ' '))))
#     with open('../data.json', 'w', encoding='utf-8') as f:
#         json.dump(json.loads(json.dumps(resultGet.decode('utf-8').replace('\r', ''))), f, ensure_ascii=False, indent=4)
# except APIException as e:
#     print(e)
#
# spec_validator = ResolvingParser(os.getcwd().replace('/Test', '') + '/restcountries.yaml')
# print(spec_validator.specification)
#
# spec_validator_weather = ResolvingParser('https://weather.talkpython.fm/openapi.json')
# print(spec_validator_weather.specification)

# output_file: Path = Path('/Users/bikashroy/PycharmProjects/umbrella') / 'countries_model.py'
# return_code: Exit = main(
#             [
#                 '--input',
#                 str('/Users/bikashroy/PycharmProjects/umbrella/restcountries.yaml'),
#                 '--output',
#                 str(output_file),
#                 '--input-file-type',
#                 'auto',
#             ]
#         )
#
# output_file: Path = Path('/Users/bikashroy/PycharmProjects/umbrella') / 'weather_model.py'
# return_code: Exit = main(
#             [
#                 '--url',
#                 'https://weather.talkpython.fm/openapi.json',
#                 '--output',
#                 str(output_file),
#                 '--input-file-type',
#                 'auto',
#             ]
#         )

# def props(cls):
#     return [i for i in cls.__dict__.keys() if i[:1] != '_']
#
#
# country = props(countries_model.Country())
# weather = props(weather_model.Forecast())
# country.extend(weather)
#
# save_path = '/models'
# file_name = f'combined_attributes.py'
# complete_name = os.path.join(save_path, file_name)
# file = open(complete_name, 'w')
# file.writelines("from typing import Optional\n")
# file.writelines("from pydantic import BaseModel\n")
# file.writelines("\n")
# file.writelines("\n")
# file.writelines("class Output(BaseModel):\n")
# for attr in country:
#     file.writelines("\t" + attr + " = None" + "\n")
# file.close()

# def Merge(dict1, dict2):
#     res = {**dict1, **dict2}
#     return res
#
#
# # Driver code
# dict1 = {'a': 10, 'b': 8}
# dict2 = {'a': 6, 'b': 4}
# dict3 = Merge(dict1, dict2)
# print(dict3)

# (os.getcwd().replace("Test", "")/"custom_template"
# main('--input', '/Users/bikashroy/PycharmProjects/umbrella/weather.yaml', '--output', 'app')
files = [f for f in listdir(Path(os.getcwd().replace("/Test", ""))/"custom_template") if isfile(join(Path(os.getcwd().replace("/Test", ""))/"custom_template", f))]
os.rename(os.getcwd().replace("Test", "custom_template/") + files[0], os.getcwd().replace("Test", "custom_template/") + f'methods_1.jinja2')
oas_file = Path(os.getcwd().replace("/Test", ""))/"weather.yaml"
output = Path('app1')
generate_code(
    input_name=oas_file.name,
    input_text=oas_file.read_text(),
    output_dir=output,
    template_dir=Path(os.getcwd().replace("/Test", ""))/"custom_template",
)
with open(os.getcwd().replace("/Test", "") + "/main.py", 'r+') as f:
    lines = f.readlines()
    for i, line in enumerate(lines):
        if 'service_composition_api' in line:
            lines.insert(i, f"api.include_router(methods_1)")
    f.truncate(0)  # truncates the file
    f.seek(0)  # moves the pointer to the start of the file
    f.writelines(lines)  # write the new data to the file