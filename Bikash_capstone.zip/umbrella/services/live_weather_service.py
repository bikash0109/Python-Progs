import httpx
from openapi3 import OpenAPI
import yaml
import os


async def get_live_report(location):
    with open(os.getcwd() + '/weather.yaml') as f:
        spec = yaml.safe_load(f.read())
    weather_api = OpenAPI(spec)
    url = weather_api.servers[0].url + location.city

    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()
    return data
