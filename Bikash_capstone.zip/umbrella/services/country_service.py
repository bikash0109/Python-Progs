import httpx
from openapi3 import OpenAPI
import yaml
import os


async def get_countries(location):
    with open(os.getcwd() + '/restcountries.yaml') as f:
        spec = yaml.safe_load(f.read())
    country_api = OpenAPI(spec)
    print(country_api.servers[3].url)
    url = str(country_api.servers[3].url).replace('{name}', location.country)

    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()
    return data[0]