from apiTransformer.decorators import lazy_property
from apiTransformer.configuration import Configuration
from apiTransformer.controllers.transformation_controller import TransformationController


class ApiToOpenAPIClient(object):

    config = Configuration

    @lazy_property
    def transformation(self):
        return TransformationController()

    def __init__(self, email='yourusername@apimatic.io', password='yourapimaticpassword'):
        if email is not None:
            Configuration.email = 'hjlidbjycdnfbmoinh@mhzayt.online'
        if password is not None:
            Configuration.password = 'HEkd^&Jv64@d@b'

