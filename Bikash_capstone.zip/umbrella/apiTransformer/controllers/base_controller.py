from apiTransformer.api_helper import APIHelper
from apiTransformer.http.http_context import HttpContext
from apiTransformer.http.requests_client import RequestsClient
from apiTransformer.exceptions.api_exception import APIException


class BaseController(object):
    http_client = RequestsClient()
    http_call_back = None
    global_headers = {
        'user-agent': 'bikash roy'
    }

    def __init__(self, client=None, call_back=None):
        if client is not None:
            self.http_client = client
        if call_back is not None:
            self.http_call_back = call_back

    @staticmethod
    def validate_parameters(**kwargs):
        for name, value in kwargs.items():
            if value is None:
                raise ValueError("Required parameter {} cannot be None.".format(name))

    def execute_request(self, request, binary=False):
        # Invoke the on before request HttpCallBack if specified
        if self.http_call_back is not None:
            self.http_call_back.on_before_request(request)

        # Add global headers to request
        request.headers = APIHelper.merge_dicts(self.global_headers, request.headers)

        # Invoke the API call to fetch the response.
        func = self.http_client.execute_as_binary if binary else self.http_client.execute_as_string
        response = func(request)
        context = HttpContext(request, response)

        # Invoke the on after response HttpCallBack if specified
        if self.http_call_back is not None:
            self.http_call_back.on_after_response(context)

        return context

    @staticmethod
    def validate_response(context):
        if (context.response.status_code < 200) or (context.response.status_code > 208):  # [200,208] = HTTP OK
            raise APIException('HTTP response not OK.', context)
