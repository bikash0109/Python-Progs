from apiTransformer.api_helper import APIHelper
from apiTransformer.configuration import Configuration
from apiTransformer.controllers.base_controller import BaseController
from apiTransformer.http.auth.basic_auth import BasicAuth
from apiTransformer.models.transformation import Transformation


class TransformationController(BaseController):

    def download_transformed_file(self, transformation_id):
        # Prepare query URL
        _url_path = '/transformations/{transformationId}/converted-file'
        _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
            'transformationId': transformation_id
        })
        _query_builder = Configuration.get_base_uri()
        _query_builder += _url_path
        _query_url = APIHelper.clean_url(_query_builder)

        # Prepare and execute request
        _request = self.http_client.get(_query_url)
        BasicAuth.apply(_request)
        _context = self.execute_request(_request, binary=True)
        self.validate_response(_context)

        # Return appropriate type
        return _context.response.raw_body

    def transform_via_url(self, ur_laddress):
        # Prepare query URL
        _url_path = '/transformations'
        _query_builder = Configuration.get_base_uri()
        _query_builder += _url_path
        _query_url = APIHelper.clean_url(_query_builder)

        # Prepare headers
        _headers = {
            'accept': 'application/json',
            'content-type': 'application/vnd.apimatic.urlTransformDto.v1+json'
        }

        # Prepare and execute request
        _request = self.http_client.post(_query_url, headers=_headers, parameters=APIHelper.json_serialize(ur_laddress))
        BasicAuth.apply(_request)
        _context = self.execute_request(_request)
        self.validate_response(_context)
        return APIHelper.json_deserialize(_context.response.raw_body, Transformation.from_dictionary)

    def delete_transformation(self, transformation_id):
        # Prepare query URL
        _url_path = '/transformations/{transformationId}'
        _url_path = APIHelper.append_url_with_template_parameters(_url_path, {
            'transformationId': transformation_id
        })
        _query_builder = Configuration.get_base_uri()
        _query_builder += _url_path
        _query_url = APIHelper.clean_url(_query_builder)

        # Prepare and execute request
        _request = self.http_client.delete(_query_url)
        BasicAuth.apply(_request)
        _context = self.execute_request(_request)
        self.validate_response(_context)
