class UrlTransformationInput(object):
    # Create a mapping from Model property names to API property names
    _names = {
        "file_url":'fileUrl',
        "export_format":'exportFormat',
        "code_gen_version":'codeGenVersion'
    }

    def __init__(self,
                 file_url=None,
                 export_format=None,
                 code_gen_version=None):

        # Initialize members of the class
        self.file_url = file_url
        self.export_format = export_format
        self.code_gen_version = code_gen_version


    @classmethod
    def from_dictionary(cls,
                        dictionary):
        if dictionary is None:
            return None
        # Extract variables from the dictionary
        file_url = dictionary.get('fileUrl')
        export_format = dictionary.get('exportFormat')
        code_gen_version = dictionary.get('codeGenVersion')

        # Return an object of this model
        return cls(file_url,
                   export_format,
                   code_gen_version)
