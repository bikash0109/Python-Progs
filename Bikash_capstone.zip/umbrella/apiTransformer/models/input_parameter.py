
class InputParameter(object):
    # Create a mapping from Model property names to API property names
    _names = {
        "is_null":'isNull',
        "endpoint_input_prameter_id":'endpointInputPrameterId',
        "id":'id',
        "name":'name',
        "value":'value'
    }

    def __init__(self,
                 is_null=None,
                 endpoint_input_prameter_id=None,
                 id=None,
                 name=None,
                 value=None):
        """Constructor for the InputParameter class"""

        # Initialize members of the class
        self.is_null = is_null
        self.endpoint_input_prameter_id = endpoint_input_prameter_id
        self.id = id
        self.name = name
        self.value = value


    @classmethod
    def from_dictionary(cls,
                        dictionary):
        if dictionary is None:
            return None

        # Extract variables from the dictionary
        is_null = dictionary.get('isNull')
        endpoint_input_prameter_id = dictionary.get('endpointInputPrameterId')
        id = dictionary.get('id')
        name = dictionary.get('name')
        value = dictionary.get('value')

        # Return an object of this model
        return cls(is_null,
                   endpoint_input_prameter_id,
                   id,
                   name,
                   value)


