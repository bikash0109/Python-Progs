class ExportFormats(object):
    WSDL = 'WSDL'
    SWAGGER10 = 'Swagger10'
    SWAGGER20 = 'Swagger20'
    SWAGGERYAML = 'SwaggerYaml'
    OPENAPI3JSON = 'OpenApi3Json'
    OPENAPI3YAML = 'OpenApi3Yaml'
    POSTMAN10 = 'Postman10'
    POSTMAN20 = 'Postman20'

