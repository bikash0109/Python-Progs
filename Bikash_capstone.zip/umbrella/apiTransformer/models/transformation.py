class Transformation(object):
    # Create a mapping from Model property names to API property names
    _names = {
        "id":'id',
        "transformed_on":'transformedOn',
        "user_id":'userId',
        "inputted_file":'inputtedFile',
        "generated_file":'generatedFile',
        "export_format":'exportFormat',
        "transformation_source":'transformationSource',
        "transformation_input":'transformationInput',
        "code_gen_version":'codeGenVersion',
        "success":'success'
    }

    def __init__(self,
                 id=None,
                 transformed_on=None,
                 user_id=None,
                 inputted_file=None,
                 generated_file=None,
                 export_format=None,
                 transformation_source=None,
                 transformation_input=None,
                 code_gen_version=None,
                 success=None):
        # Initialize members of the class
        self.id = id
        self.transformed_on = transformed_on
        self.user_id = user_id
        self.inputted_file = inputted_file
        self.generated_file = generated_file
        self.export_format = export_format
        self.transformation_source = transformation_source
        self.transformation_input = transformation_input
        self.code_gen_version = code_gen_version
        self.success = success


    @classmethod
    def from_dictionary(cls,
                        dictionary):
        if dictionary is None:
            return None
        # Extract variables from the dictionary
        id = dictionary.get('id')
        transformed_on = dictionary.get('transformedOn')
        user_id = dictionary.get('userId')
        inputted_file = dictionary.get('inputtedFile')
        generated_file = dictionary.get('generatedFile')
        export_format = dictionary.get('exportFormat')
        transformation_source = dictionary.get('transformationSource')
        transformation_input = dictionary.get('transformationInput')
        code_gen_version = dictionary.get('codeGenVersion')
        success = dictionary.get('success')
        # Return an object of this model
        return cls(id,
                   transformed_on,
                   user_id,
                   inputted_file,
                   generated_file,
                   export_format,
                   transformation_source,
                   transformation_input,
                   code_gen_version,
                   success)
