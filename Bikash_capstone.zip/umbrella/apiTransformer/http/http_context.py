class HttpContext(object):
    def __init__(self,
                 request,
                 response):
        self.request = request
        self.response = response
