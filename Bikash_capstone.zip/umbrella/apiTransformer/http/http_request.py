from apiTransformer.api_helper import APIHelper


class HttpRequest(object):
    def __init__(self,
                 http_method,
                 query_url,
                 headers=None,
                 query_parameters=None,
                 parameters=None,
                 files=None):
        self.http_method = http_method
        self.query_url = query_url
        self.headers = headers
        self.query_parameters = query_parameters
        self.parameters = parameters
        self.files = files

    def add_header(self, name, value):
        self.headers[name] = value

    def add_parameter(self, name, value):
        self.parameters[name] = value

    def add_query_parameter(self, name, value):
        self.query_url = APIHelper.append_url_with_query_parameters(self.query_url,
                                                                    {name:value})
        self.query_url = APIHelper.clean_url(self.query_url)
