import base64
from apiTransformer.configuration import Configuration


class BasicAuth:

    @staticmethod
    def apply(http_request):
        username = Configuration.email
        password = Configuration.password
        joined = "{}:{}".format(username, password)
        encoded = base64.b64encode(str.encode(joined)).decode('iso-8859-1')
        header_value = "Basic {}".format(encoded)
        http_request.headers["Authorization"] = header_value