class HttpMethodEnum(object):
    GET = "GET"

    POST = "POST"

    PUT = "PUT"

    PATCH = "PATCH"

    DELETE = "DELETE"

    HEAD = "HEAD"

    @classmethod
    def to_string(cls, val):
        for k, v in list(vars(cls).items()):
            if v == val:
                return k

    @classmethod
    def from_string(cls, str):
        return getattr(cls, str.upper(), None)
