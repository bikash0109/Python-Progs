class HttpResponse(object):
    def __init__(self,
                 status_code,
                 headers,
                 raw_body):
        self.status_code = status_code
        self.headers = headers
        self.raw_body = raw_body
