from apiTransformer.http.http_method_enum import HttpMethodEnum
from apiTransformer.http.http_request import HttpRequest


class HttpClient(object):
    def get(self, query_url,
            headers={},
            query_parameters={}):
        return HttpRequest(HttpMethodEnum.GET,
                           query_url,
                           headers,
                           query_parameters,
                           None,
                           None)

    def head(self, query_url,
            headers={},
            query_parameters={}):
        return HttpRequest(HttpMethodEnum.HEAD,
                           query_url,
                           headers,
                           query_parameters,
                           None,
                           None)

    def post(self, query_url,
             headers={},
             query_parameters={},
             parameters={},
             files={}):
        return HttpRequest(HttpMethodEnum.POST,
                           query_url,
                           headers,
                           query_parameters,
                           parameters,
                           files)

    def put(self, query_url,
            headers={},
            query_parameters={},
            parameters={},
            files={}):
        return HttpRequest(HttpMethodEnum.PUT,
                           query_url,
                           headers,
                           query_parameters,
                           parameters,
                           files)

    def patch(self, query_url,
              headers={},
              query_parameters={},
              parameters={},
              files={}):
        return HttpRequest(HttpMethodEnum.PATCH,
                           query_url,
                           headers,
                           query_parameters,
                           parameters,
                           files)

    def delete(self, query_url,
               headers={},
               query_parameters={},
               parameters={},
               files={}):
        return HttpRequest(HttpMethodEnum.DELETE,
                           query_url,
                           headers,
                           query_parameters,
                           parameters,
                           files)
