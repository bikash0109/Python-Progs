from apiTransformer.api_helper import APIHelper


class Configuration(object):
    email = 'yourusername@apimatic.io'

    password = 'yourapimaticpassword'

    @classmethod
    def get_base_uri(cls):
        return 'https://www.apimatic.io/api'
