class APIException(Exception):
    def __init__(self,
                 reason,
                 context):
        super(APIException, self).__init__(reason)
        self.context = context
        self.response_code = context.response.status_code
