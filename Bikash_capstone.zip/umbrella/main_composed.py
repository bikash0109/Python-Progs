import fastapi
import uvicorn
from views import home2
from services_2 import methods_2
from services_1 import methods_1

api = fastapi.FastAPI()


def configure():
    api.include_router(home2.router)
    api.include_router(methods_2.router)
    api.include_router(methods_1.router)


configure()
if __name__ == '__main__':
    uvicorn.run(api, port=5000)