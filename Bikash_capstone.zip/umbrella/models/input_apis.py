from typing import Optional

from pydantic import BaseModel


class Input_apis(BaseModel):
    apis: Optional[str] = None
