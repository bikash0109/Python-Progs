from typing import Optional
from pydantic import BaseModel


class UmbrellaStatus(BaseModel):
    city: Optional[str] = None
    country: Optional[str] = None
    capital_city: Optional[str] = None
    population: Optional[str] = None
    borders: Optional[str] = None
    native_name: Optional[str] = None
    currency: Optional[str] = None
    native_language: Optional[str] = None
    bring_umbrella: Optional[bool] = False
    temp: Optional[str] = None
    weather: Optional[str] = None
    error: Optional[str] = None
