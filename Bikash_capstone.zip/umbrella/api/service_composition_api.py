from apiTransformer.apiTransformer import ApiToOpenAPIClient
from apiTransformer.models.url_transformation_input import UrlTransformationInput
from apiTransformer.models.export_formats import ExportFormats
from apiTransformer.exceptions.api_exception import APIException
import fastapi
from models.location import Location
from models.input_apis import Input_apis
from services import live_weather_service
from services import country_service
import os
from fastapi_code_generator.__main__ import generate_code
from pathlib import Path
from os import listdir
from os.path import isfile, join
import main_composed

router = fastapi.APIRouter()


@router.get('/api/umbrella/get_end_point', responses=None)
async def get_end_point(input_apis: Input_apis = fastapi.Depends()):
    urls = input_apis.apis.split(',')
    counter = 1
    for url in urls:
        await generate_models(url.strip(), counter)
        counter += 1
    return None


@router.get('/api/umbrella/country_information', response_model=None)
async def get_country_information(location: Location = fastapi.Depends()):

    # call ApiMatic module

    # generate models

    # generate individual api classes


    countries = await country_service.get_countries(location)

    # call weather api
    location.city = countries.get('capital', {})
    location.country = countries.get('alpha2Code', {})
    data = await live_weather_service.get_live_report(location)
    merged = {**countries, **data}
    return merged


async def call_apimatic():
    client = ApiToOpenAPIClient()
    transformation_controller = client.transformation
    ur_laddress = UrlTransformationInput()
    ur_laddress.file_url = 'https://restcountries.eu/rest/v2/all'
    ur_laddress.export_format = ExportFormats.OPENAPI3YAML
    ur_laddress.code_gen_version = 1

    try:
        result = transformation_controller.transform_via_url(ur_laddress)
        print(result.id)
    except APIException as e:
        print(e)

    transformation_controller = client.transformation
    transformation_id = result.id

    try:
        resultGet = transformation_controller.download_transformed_file(transformation_id)
        print(resultGet)
        # with open('restcounntries.yaml', 'w') as f:
        #     f.writelines(str(resultGet))
    except APIException as e:
        print(e)
    return


async def generate_models(filepath, counter):
    # get template file
    files = [f for f in listdir(Path(os.getcwd())/"custom_template") if isfile(join(Path(os.getcwd())/"custom_template", f))]
    os.rename(os.getcwd() + "/custom_template/" + files[0], os.getcwd() + "/custom_template/" + f'methods_{counter}.jinja2')
    oas_file = Path(filepath)
    output = Path(f'services_{counter}')
    generate_code(
        input_name=oas_file.name,
        input_text=oas_file.read_text(),
        output_dir=output,
        template_dir=Path(os.getcwd())/"custom_template",
    )
    await write_to_main(counter)


async def write_to_main(counter):
    file = open(os.getcwd() + "/main_composed.py", 'r+')
    lines = file.readlines()
    for i, line in enumerate(lines):
        if 'from views import home2' in line and f'from services_{counter} import methods_{counter}' not in lines:
            lines.insert(i+1, f"from services_{counter} import methods_{counter}\n")
        if 'api.include_router(home2.router)' in line and f"    api.include_router(methods_{counter}.router)\n" not in lines:
            lines.insert(i + 1, f"    api.include_router(methods_{counter}.router)\n")
    file.truncate(0)  # truncates the file
    file.seek(0)  # moves the pointer to the start of the file
    file.writelines(lines)  # write the new data to the file
    file.close()
    return None


# async def write_url_services(url, counter, input):
#     save_path = '/services'
#     file_name = f'service_{counter}.py'
#     complete_name = os.path.join(save_path, file_name)
#     file = open(complete_name, 'w')
#     file.writelines("import httpx\nfrom openapi3 import OpenAPI\nimport yaml\nimport os\n\n\n")
#     file.writelines(f"async def get_service{counter}({input})\n")
#     file.writelines("\t" + f"async with httpx.AsyncClient() as client:\n")
#     file.writelines("\t\t\t\t" + f"resp = await client.get(url)\n")
#     file.writelines("\t\t\t\t" + f"resp.raise_for_status()\n")
#     file.writelines("\t\t\t\t" + f"data = resp.json()\n")
#     file.writelines("\t" + f"return data[0]\n")
#     file.close()

# async def get_unified_model(models):
#     country = props(countries_model.Country())
#     weather = props(weather_model.Forecast())
#     country.extend(weather)
#     save_path = '/models'
#     file_name = f'combined_attributes.py'
#     complete_name = os.path.join(save_path, file_name)
#     file = open(complete_name, 'w')
#     file.writelines("from typing import Optional\n")
#     file.writelines("from pydantic import BaseModel\n")
#     file.writelines("\n")
#     file.writelines("\n")
#     file.writelines("class Output(BaseModel):\n")
#     for attr in country:
#         file.writelines("\t" + attr + " = None" + "\n")
#     file.close()
#
#
# def props(cls):
#     return [i for i in cls.__dict__.keys() if i[:1] != '_']






















































































# @router.get('/api/umbrella/city_weather', response_model=None)
# async def get_city_information(location: Location = fastapi.Depends()):
#     # call weather api
#     if location.city:
#         data = await live_weather_service.get_live_report(location)
#     else:
#         return UmbrellaStatus(error='City is required')
#
#     # call country api
#     country_from_weather_api = data.get('location', {})
#     location.alpha_code = country_from_weather_api.get('country', {})
#     countries = await country_service.get_countries(location)
#
#     merged = {**countries, **data}
#     return merged
